F�r eine farbliche und organisatorische Trennung habe ich zwei Shapefile Dateien erstellt. 
Die flood_risk_areas.shp Dateien stellen alle Hochwasserrisikogebiete im Untersuchungsraum dar. 
Die floodrisk areas2.shp Dateien stellen die Hochwasserrisikogebiete in urbanen R�umen dar.


Gr��e